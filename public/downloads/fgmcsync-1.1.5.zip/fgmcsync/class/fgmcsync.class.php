<?php
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';

class FgmcSync
{
	private $db;
	private $dolibarrLogin;
	private $dolibarrPassword;
	public function __construct($db) { $this->db = $db; }

	private function request($base, $path, $key, $method = 'GET', $body = null, $integrationToken = null)
	{
		$url = rtrim($base, '/').'/'.ltrim($path, '/');
		$headers = array('Accept: application/json');
		if ($key) {
			$headers[] = 'DOLAPIKEY: '.$key;
			if ($this->dolibarrLogin !== null && $this->dolibarrPassword !== null) {
				$headers[] = 'Authorization: Basic '.base64_encode($this->dolibarrLogin.':'.$this->dolibarrPassword);
			}
		}
		if ($integrationToken) $headers[] = 'X-FGMC-Integration-Token: '.$integrationToken;
		if ($body !== null) $headers[] = 'Content-Type: application/json';
		$ch = curl_init($url);
		curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $headers, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_TIMEOUT => 90, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2));
		if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
		$response = curl_exec($ch); $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
		if ($response === false || $status < 200 || $status >= 300) throw new Exception('HTTP '.$status.' '.$method.' '.$url.': '.($error ?: substr((string) $response, 0, 500)));
		$data = json_decode((string) $response, true);
		return $data === null && $response !== 'null' ? $response : $data;
	}

	private function findByExternalRef($api, $key, $resource, $reference)
	{
		for ($page = 0; $page < 100; $page++) {
			try {
				$rows = $this->request($api, $resource.'?limit=100&page='.$page, $key);
			} catch (Exception $e) {
				// Dolibarr returns HTTP 404 (rather than an empty array) when a
				// collection has no records. Treat that as no match so the sync can
				// create the first third party/order instead of aborting.
				if (stripos($e->getMessage(), 'HTTP 404') !== false && preg_match('/No [a-z ]+ found/i', $e->getMessage())) {
					return null;
				}
				throw $e;
			}
			if (!is_array($rows) || !$rows) return null;
			foreach ($rows as $row) if (($row['ref_ext'] ?? '') === $reference) return $row['id'] ?? $row['rowid'] ?? null;
			if (count($rows) < 100) return null;
		}
		return null;
	}

	private function isDolibarrNotFound($error)
	{
		$message = $error instanceof Exception ? $error->getMessage() : (string) $error;
		return stripos($message, 'HTTP 404') !== false && stripos($message, 'not found') !== false;
	}

	private function verifyLinkedRecord($api, $key, $resource, $id, $reference)
	{
		if (!$id) return null;
		try {
			$record = $this->request($api, $resource.'/'.$id, $key);
		} catch (Exception $e) {
			if ($this->isDolibarrNotFound($e)) return null;
			throw $e;
		}
		$externalRef = trim((string) ($record['ref_ext'] ?? ''));
		if ($externalRef !== '' && $externalRef !== $reference) return null;
		if ($externalRef === '') $this->request($api, $resource.'/'.$id, $key, 'PUT', array('ref_ext' => $reference));
		return (string) $id;
	}

	private function ensureOrderIsDraft($api, $key, $orderId)
	{
		$order = $this->request($api, 'orders/'.$orderId, $key);
		$status = $order['statut'] ?? $order['status'] ?? null;
		if (is_numeric($status) && (int) $status === 0) return;
		$this->request($api, 'orders/'.$orderId.'/settodraft', $key, 'POST');
		$order = $this->request($api, 'orders/'.$orderId, $key);
		$status = $order['statut'] ?? $order['status'] ?? null;
		if (!is_numeric($status) || (int) $status !== 0) {
			throw new Exception('Dolibarr order '.$orderId.' is not in draft status and could not be returned to draft.');
		}
	}

	private function pushProducts($api, $key, $shop, $token, $syncProducts, $syncStock)
	{
		$count = 0;
		// Import standalone products and variant parents, never variant child
		// products (which would otherwise appear as duplicate store listings).
		foreach (array(1, 2) as $variantFilter) {
			$page = 0;
			do {
				$items = $this->request($api, 'products?limit=100&page='.$page.'&variant_filter='.$variantFilter, $key);
				if (!is_array($items) || !$items) break;
			$products = array(); $stocks = array();
			foreach ($items as $p) {
				if (empty($p['id'])) continue;
				$products[] = array('id' => $p['id'], 'ref' => $p['ref'] ?? ('DOL-'.$p['id']), 'label' => $p['label'] ?? ($p['ref'] ?? 'Dolibarr product'), 'description' => $p['description'] ?? '', 'price' => $p['price'] ?? 0, 'price_ttc' => $p['price_ttc'] ?? null, 'tva_tx' => $p['tva_tx'] ?? 0, 'stock' => $p['stock_reel'] ?? $p['stock'] ?? 0, 'status' => $p['status'] ?? 1, 'image' => '');
				$stocks[] = array('id' => $p['id'], 'qty' => $p['stock_reel'] ?? $p['stock'] ?? 0);
			}
			if ($products) {
				if ($syncProducts) $this->request($shop, 'integrations/dolibarr/products', null, 'POST', array('items' => $products), $token);
				if ($syncStock) $this->request($shop, 'integrations/dolibarr/stock', null, 'POST', array('items' => $stocks), $token);
				$count += count($products);
			}
				$page++;
			} while (count($items) === 100 && $page < 1000);
		}
		return $count;
	}

	private function pushInvoices($api, $key, $shop, $token)
	{
		$items = $this->request($api, 'invoices?limit=100', $key); if (!is_array($items) || !$items) return 0;
		$invoices = array();
		foreach ($items as $invoice) if (!empty($invoice['id'])) $invoices[] = $invoice;
		if ($invoices) $this->request($shop, 'integrations/dolibarr/invoices', null, 'POST', array('items' => $invoices), $token);
		return count($invoices);
	}

	private function stableRef($prefix, $value)
	{
		return strtoupper($prefix).'-'.strtoupper(substr(sha1((string) $value), 0, 16));
	}

	private function ensureAttribute($api, $key, $label)
	{
		$normalized = function_exists('mb_strtolower') ? mb_strtolower(trim($label), 'UTF-8') : strtolower(trim($label));
		$reference = $this->stableRef('FGMC-ATTR', $normalized);
		$items = $this->request($api, 'products/attributes?limit=100&page=0', $key);
		foreach (is_array($items) ? $items : array() as $item) {
			if (($item['ref_ext'] ?? '') === $reference || ($item['ref'] ?? '') === $reference) return (int) ($item['id'] ?? $item['rowid']);
		}
		$id = $this->request($api, 'products/attributes', $key, 'POST', array('ref' => $reference, 'label' => trim($label), 'ref_ext' => $reference));
		return (int) (is_array($id) ? ($id['id'] ?? $id['rowid'] ?? 0) : $id);
	}

	private function ensureAttributeValue($api, $key, $attributeId, $attributeLabel, $value)
	{
		$value = trim((string) $value);
		if ($value === '') throw new Exception('A product combination contains an empty option value.');
		$normalized = function_exists('mb_strtolower') ? mb_strtolower($attributeLabel.'|'.$value, 'UTF-8') : strtolower($attributeLabel.'|'.$value);
		$normalizedValue = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
		$reference = $this->stableRef('FGMC-VAL', $normalized);
		try {
			$items = $this->request($api, 'products/attributes/'.$attributeId.'/values', $key);
		} catch (Exception $e) {
			if (stripos($e->getMessage(), 'HTTP 404') === false || stripos($e->getMessage(), 'Attribute values not found') === false) throw $e;
			$items = array();
		}
		foreach (is_array($items) ? $items : array() as $item) {
			$itemValue = (string) ($item['value'] ?? '');
			$itemNormalizedValue = function_exists('mb_strtolower') ? mb_strtolower($itemValue, 'UTF-8') : strtolower($itemValue);
			if (($item['ref'] ?? '') === $reference || $itemNormalizedValue === $normalizedValue) return (int) ($item['id'] ?? $item['rowid']);
		}
		$id = $this->request($api, 'products/attributes/'.$attributeId.'/values', $key, 'POST', array('ref' => $reference, 'value' => $value));
		return (int) (is_array($id) ? ($id['id'] ?? $id['rowid'] ?? 0) : $id);
	}

	private function adjustCombinationStock($api, $key, $variantProductId, $warehouseId, $targetQty, $variantLabel, $variantRef)
	{
		$stock = $this->request($api, 'products/'.$variantProductId.'/stock?selected_warehouse_id='.$warehouseId, $key);
		$warehouses = $stock['stock_warehouses'] ?? $stock['stock_warehouse'] ?? array();
		$warehouse = $warehouses[$warehouseId] ?? $warehouses[(string) $warehouseId] ?? null;
		$currentQty = null;
		if (is_array($warehouse)) {
			foreach (array('real', 'stock_reel', 'stock', 'qty') as $field) {
				if (isset($warehouse[$field]) && is_numeric($warehouse[$field])) { $currentQty = (float) $warehouse[$field]; break; }
			}
		} elseif (is_numeric($warehouse)) {
			$currentQty = (float) $warehouse;
		}
		if ($currentQty === null && empty($warehouses)) $currentQty = 0;
		if ($currentQty === null) throw new Exception('Could not read Dolibarr stock for combination '.$variantRef.' in warehouse '.$warehouseId.'.');
		$delta = (float) $targetQty - $currentQty;
		if (abs($delta) < 0.000001) return;
		$this->request($api, 'stockmovements', $key, 'POST', array(
			'product_id' => (int) $variantProductId,
			'warehouse_id' => (int) $warehouseId,
			'qty' => $delta,
			'label' => 'FGMC stock sync: '.$variantLabel,
			'movementcode' => 'FGMC-'.strtoupper(substr(sha1($variantRef.'|'.$targetQty), 0, 16)),
		));
	}

	private function pullProducts($api, $key, $shop, $token, $warehouseId)
	{
		$data = $this->request($shop, 'integrations/dolibarr/products', null, 'GET', null, $token);
		$items = $data['items'] ?? array();
		foreach ($items as $product) {
			if (!empty($product['combinaisons']) && !$warehouseId) throw new Exception('Set the Dolibarr warehouse ID in the FGMC Sync module settings before syncing combination stock.');
		}
		$count = 0;
		$combinationCount = 0;
		foreach ($items as $product) {
			if (empty($product['id'])) continue;
			$reference = 'FGMC-PRODUCT-'.$product['id'];
			$ref = trim((string) ($product['sku'] ?? '')) ?: 'FGMC-'.$product['id'];
			$tax = is_numeric($product['tax'] ?? null) ? (float) $product['tax'] : 0;
			$priceHt = is_numeric($product['price'] ?? null) ? (float) $product['price'] : 0;
			$payload = array(
				'ref' => $ref, 'ref_ext' => $reference,
				'label' => trim((string) ($product['title'] ?? '')) ?: $ref,
				'description' => (string) (($product['description'] ?? '') ?: ($product['shortDescription'] ?? '')),
				'price' => round($priceHt, 6), 'tva_tx' => $tax,
				'type' => 0, 'tosell' => 1, 'tobuy' => 0,
				'status' => ($product['status'] ?? '') === 'PUBLIC' ? 1 : 0, 'status_buy' => 0,
			);
			$id = $product['dolibarrId'] ?? null;
			if (!$id) $id = $this->findByExternalRef($api, $key, 'products', $reference);
			if ($id) {
				try {
					$this->request($api, 'products/'.$id, $key, 'PUT', $payload);
				} catch (Exception $e) {
					if (!$this->isDolibarrNotFound($e)) throw $e;
					// The saved Dolibarr ID may point to a product that was deleted.
					// Re-resolve by our stable external reference before creating a replacement.
					$id = $this->findByExternalRef($api, $key, 'products', $reference);
					if ($id) $this->request($api, 'products/'.$id, $key, 'PUT', $payload);
				}
			}
			if (!$id) {
				$created = $this->request($api, 'products', $key, 'POST', $payload);
				$id = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if (!$id) throw new Exception('Dolibarr did not return an ID for product '.$ref.'.');
			if (empty($product['dolibarrId']) || (string) $product['dolibarrId'] !== (string) $id) $this->request($shop, 'integrations/dolibarr/products/'.$product['id'].'/link', null, 'POST', array('dolibarrId' => (string) $id), $token);
			$variants = $this->request($api, 'products/'.$id.'/variants', $key);
			$variants = is_array($variants) ? $variants : array();
			$parentPrice = (float) $priceHt;
			foreach (($product['combinaisons'] ?? array()) as $variant) {
				$options = is_array($variant['options'] ?? null) ? $variant['options'] : array();
				if (!$options) throw new Exception('Combination '.$variant['id'].' on product '.$ref.' has no attribute values.');
				$features = array();
				foreach ($options as $option) {
					$attributeLabel = trim((string) ($option['attributeName'] ?? ''));
					$attributeValue = trim((string) ($option['termName'] ?? ''));
					if ($attributeLabel === '' || $attributeValue === '') throw new Exception('Combination '.$variant['id'].' has an incomplete attribute option.');
					$attributeId = $this->ensureAttribute($api, $key, $attributeLabel);
					$valueId = $this->ensureAttributeValue($api, $key, $attributeId, $attributeLabel, $attributeValue);
					$features[(string) $attributeId] = (int) $valueId;
				}
				$variantRef = trim((string) ($variant['sku'] ?? '')) ?: ($ref.'-V-'.substr(sha1((string) $variant['id']), 0, 8));
				$variantExternalRef = 'FGMC-COMBINATION-'.$variant['id'];
				$variantPrice = is_numeric($variant['price'] ?? null) ? (float) $variant['price'] : $parentPrice;
				$variantData = null;
				foreach ($variants as $candidate) {
					if (($candidate['variation_ref_ext'] ?? '') === $variantExternalRef || (!empty($variant['dolibarrId']) && (string) ($candidate['fk_product_child'] ?? '') === (string) $variant['dolibarrId'])) { $variantData = $candidate; break; }
				}
				$variantPayload = array(
					'weight_impact' => 0,
					'price_impact' => round($variantPrice - $parentPrice, 6),
					'price_impact_is_percent' => false,
					'features' => (object) $features,
					'reference' => $variantRef,
					'ref_ext' => $variantExternalRef,
				);
				if ($variantData) {
					$this->request($api, 'products/variants/'.$variantData['id'], $key, 'PUT', array('variation_price' => $variantPayload['price_impact'], 'variation_price_percentage' => false, 'variation_ref_ext' => $variantExternalRef));
					if (!empty($variantData['fk_product_child'])) $this->request($api, 'products/'.$variantData['fk_product_child'], $key, 'PUT', array('ref' => $variantRef));
				} else {
					$this->request($api, 'products/'.$id.'/variants', $key, 'POST', $variantPayload);
				}
				$variants = $this->request($api, 'products/'.$id.'/variants', $key);
				$variants = is_array($variants) ? $variants : array();
				$variantData = null;
				foreach ($variants as $candidate) {
					if (($candidate['variation_ref_ext'] ?? '') === $variantExternalRef || (!empty($variant['dolibarrId']) && (string) ($candidate['fk_product_child'] ?? '') === (string) $variant['dolibarrId'])) { $variantData = $candidate; break; }
				}
				$childId = $variantData['fk_product_child'] ?? null;
				if (!$childId) throw new Exception('Dolibarr created combination '.$variantRef.' but did not return its child product ID.');
				if (empty($variant['dolibarrId']) || (string) $variant['dolibarrId'] !== (string) $childId) {
					$this->request($shop, 'integrations/dolibarr/products/'.$product['id'].'/variants/'.$variant['id'].'/link', null, 'POST', array('dolibarrId' => (string) $childId), $token);
				}
				$this->adjustCombinationStock($api, $key, $childId, $warehouseId, is_numeric($variant['qty'] ?? null) ? (float) $variant['qty'] : 0, $product['title'] ?? $ref, $variantRef);
				$combinationCount++;
			}
			$count++;
		}
		return array('products' => $count, 'combinations' => $combinationCount);
	}

	private function pullCustomers($api, $key, $shop, $token)
	{
		$data = $this->request($shop, 'integrations/dolibarr/customers', null, 'GET', null, $token);
		$items = $data['items'] ?? array(); $count = 0;
		foreach ($items as $customer) {
			$address = $customer['addresses'][0] ?? array();
			$name = trim(($customer['firstName'] ?? '').' '.($customer['lastName'] ?? '')) ?: ($customer['company'] ?? 'Store customer');
			$reference = 'FGMC-CUSTOMER-'.$customer['id'];
			$id = $this->verifyLinkedRecord($api, $key, 'thirdparties', $customer['dolibarrId'] ?? null, $reference);
			if (!$id) $id = $this->findByExternalRef($api, $key, 'thirdparties', $reference);
			if (!$id) {
				$created = $this->request($api, 'thirdparties', $key, 'POST', array(
					'name' => $name, 'client' => 1, 'email' => $customer['email'] ?? '', 'phone' => $customer['phoneNumber'] ?? '',
					'address' => $address['street'] ?? '', 'zip' => $address['zipCode'] ?? '', 'town' => $address['City'] ?? '',
					'country_code' => $address['country'] ?? '', 'ref_ext' => $reference,
				));
				$id = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if ($id && (string) ($customer['dolibarrId'] ?? '') !== (string) $id) { $this->request($shop, 'integrations/dolibarr/customers/'.$customer['id'].'/link', null, 'POST', array('dolibarrId' => (string) $id), $token); $count++; }
		}
		return $count;
	}

	private function pullOrders($api, $key, $shop, $token)
	{
		$data = $this->request($shop, 'integrations/dolibarr/orders', null, 'GET', null, $token);
		$items = $data['items'] ?? array(); $count = 0;
		foreach ($items as $order) {
			$client = $order['Client'] ?? array(); $address = $order['Address'] ?? array();
			$customerReference = !empty($client['id']) ? 'FGMC-CUSTOMER-'.$client['id'] : 'FGMC-ORDER-CUSTOMER-'.$order['id'];
			$socid = $this->verifyLinkedRecord($api, $key, 'thirdparties', $client['dolibarrId'] ?? null, $customerReference);
			if (!$socid) $socid = $this->findByExternalRef($api, $key, 'thirdparties', $customerReference);
			if (!$socid) {
				$name = $order['guestName'] ?? trim(($client['firstName'] ?? '').' '.($client['lastName'] ?? ''));
				$created = $this->request($api, 'thirdparties', $key, 'POST', array('name' => ($name ?: 'Store customer'), 'client' => 1, 'email' => $order['guestEmail'] ?? ($client['email'] ?? ''), 'phone' => $order['guestPhone'] ?? ($client['phoneNumber'] ?? ''), 'ref_ext' => $customerReference));
				$socid = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if (!empty($client['id']) && (string) ($client['dolibarrId'] ?? '') !== (string) $socid) {
				$this->request($shop, 'integrations/dolibarr/customers/'.$client['id'].'/link', null, 'POST', array('dolibarrId' => (string) $socid), $token);
			}
			if (!$socid) continue;
			$lines = array();
			foreach (($order['products'] ?? array()) as $product) {
				if (empty($product['dolibarrProductId'])) continue;
				$lines[] = array('fk_product' => (int) $product['dolibarrProductId'], 'qty' => (float) ($product['quantity'] ?? 1), 'subprice' => (float) ($product['unitPrice'] ?? 0), 'tva_tx' => 0, 'desc' => $product['title'] ?? '');
			}
			if (!$lines) continue;
			$orderReference = 'FGMC-ORDER-'.$order['id'];
			$id = $this->verifyLinkedRecord($api, $key, 'orders', $order['dolibarrId'] ?? null, $orderReference);
			if (!$id) $id = $this->findByExternalRef($api, $key, 'orders', $orderReference);
			if (!$id) {
				$created = $this->request($api, 'orders', $key, 'POST', array('socid' => (int) $socid, 'date' => strtotime($order['createdAt'] ?? 'now'), 'ref_ext' => $orderReference, 'note_private' => 'Ecommerce order '.$order['id'].' / payment '.$order['paymentStatus']));
				$id = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if ($id) {
				$existing = $this->request($api, 'orders/'.$id.'/lines', $key);
				if (!is_array($existing) || count($existing) === 0) {
					$this->ensureOrderIsDraft($api, $key, $id);
					foreach ($lines as $line) {
						try {
							$this->request($api, 'orders/'.$id.'/lines', $key, 'POST', array('fk_product' => $line['fk_product'], 'qty' => $line['qty'], 'subprice' => $line['subprice'], 'tva_tx' => $line['tva_tx'], 'localtax1_tx' => 0, 'localtax2_tx' => 0, 'remise_percent' => 0, 'info_bits' => 0, 'price_base_type' => 'HT', 'product_type' => 0, 'desc' => $line['desc']));
						} catch (Exception $e) {
							throw new Exception('Could not add store order '.$order['id'].' line "'.$line['desc'].'" with Dolibarr product ID '.$line['fk_product'].'. Check that the product still exists, is available for sale, and that order '.$id.' is still a draft. '.$e->getMessage());
						}
					}
				}
				if ((string) ($order['dolibarrId'] ?? '') !== (string) $id) { $this->request($shop, 'integrations/dolibarr/orders/'.$order['id'].'/link', null, 'POST', array('dolibarrId' => (string) $id), $token); $count++; }
			}
		}
		return $count;
	}

	public function run($user, $langs, $conf)
	{
		return json_encode($this->runDirection('both', $user, $langs, $conf));
	}

	public function runDirection($direction, $user, $langs, $conf)
	{
		$shop = $conf->global->FGMCSYNC_SHOP_URL ?? '';
		$token = $conf->global->FGMCSYNC_SHOP_TOKEN ?? '';
		if (!$shop || !$token) throw new Exception('FGMC Sync bootstrap connection is not configured.');
		$remote = $this->request($shop, 'integrations/dolibarr/runtime-config', null, 'GET', null, $token);
		$api = $remote['apiUrl'] ?? '';
		$key = $remote['apiKey'] ?? '';
		$this->dolibarrLogin = $remote['username'] ?? null;
		$this->dolibarrPassword = $remote['password'] ?? null;
		$warehouseId = (int) ($conf->global->FGMCSYNC_WAREHOUSE_ID ?? 0);
		if (!$api || !$key || !$this->dolibarrLogin || !$this->dolibarrPassword) throw new Exception('Dolibarr URL, Web Services key, login, or password is missing in the store admin.');
		$result = array();
		if ($direction === 'both' || $direction === 'dolibarr-to-store') {
			if (!empty($remote['syncProducts']) || !empty($remote['syncStock'])) $result['products_and_stock'] = $this->pushProducts($api, $key, $shop, $token, !empty($remote['syncProducts']), !empty($remote['syncStock']));
			if (!empty($remote['syncInvoices'])) $result['invoices'] = $this->pushInvoices($api, $key, $shop, $token);
		}
		if ($direction === 'both' || $direction === 'store-to-dolibarr') {
			if (!empty($remote['syncStoreProducts'])) {
				$productResult = $this->pullProducts($api, $key, $shop, $token, $warehouseId);
				$result['products'] = $productResult['products'];
				$result['combinations'] = $productResult['combinations'];
			}
			if (!empty($remote['syncCustomers'])) $result['customers'] = $this->pullCustomers($api, $key, $shop, $token);
			if (!empty($remote['syncOrders'])) $result['orders'] = $this->pullOrders($api, $key, $shop, $token);
		}
		return $result;
	}
}
