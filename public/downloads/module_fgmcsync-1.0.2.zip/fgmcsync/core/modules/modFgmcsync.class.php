<?php
/* Copyright (C) 2026 FGMC */

include_once DOL_DOCUMENT_ROOT . '/core/modules/DolibarrModules.class.php';

/** Dolibarr module descriptor for FGMC store synchronization. */
class modFgmcsync extends DolibarrModules
{
	public function __construct($db)
	{
		global $conf;

		$this->db = $db;
		$this->numero = 620120;
		$this->rights_class = 'fgmcsync';
		$this->family = 'interface';
		$this->module_position = 90;
		$this->name = 'FGMCSync';
		$this->description = 'Synchronize Dolibarr invoices, products and stock with the FGMC store.';
		$this->version = '1.0.2';
		$this->const_name = 'MAIN_MODULE_FGMCSYNC';
		$this->picto = 'technic';
		$this->config_page_url = array('setup.php@fgmcsync');
		$this->module_parts = array('triggers' => 1);
		$this->dirs = array();
		$this->depends = array();
		$this->requiredby = array();
		$this->conflictwith = array();
		$this->langfiles = array();
		$this->phpmin = array(7, 4);
		$this->need_dolibarr_version = array(15, 0);
		$this->warnings_activation = array();
		$this->warnings_activation_ext = array();
		$this->const = array();
		$this->tabs = array();
		$this->dictionaries = array();
		$this->menu = array();
		$this->boxes = array();
		$this->cronjobs = array();
	}
}
