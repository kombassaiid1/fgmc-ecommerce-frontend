<?php
define('NOLOGIN', 1);
define('NOCSRFCHECK', 1);
define('NOREQUIREMENU', 1);
define('NOREQUIREHTML', 1);
require_once dirname(__DIR__, 3).'/main.inc.php';

header('Content-Type: application/json; charset=utf-8');

$expected = (string) ($conf->global->FGMCSYNC_SHOP_TOKEN ?? '');
$provided = (string) ($_SERVER['HTTP_X_FGMC_INTEGRATION_TOKEN'] ?? '');
if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
	http_response_code(401);
	echo json_encode(array('ok' => false, 'message' => 'Invalid FGMC Sync token.'));
	exit;
}

$body = json_decode(file_get_contents('php://input'), true);
$direction = is_array($body) ? ($body['direction'] ?? '') : '';
if (!in_array($direction, array('store-to-dolibarr', 'dolibarr-to-store'), true)) {
	http_response_code(400);
	echo json_encode(array('ok' => false, 'message' => 'Unknown synchronization direction.'));
	exit;
}

try {
	set_time_limit(120);
	require_once DOL_DOCUMENT_ROOT.'/custom/fgmcsync/class/fgmcsync.class.php';
	$sync = new FgmcSync($db);
	$result = $sync->runDirection($direction, $user, $langs, $conf);
	echo json_encode(array('ok' => true, 'result' => $result));
} catch (Throwable $error) {
	http_response_code(500);
	echo json_encode(array('ok' => false, 'message' => $error->getMessage()));
}
