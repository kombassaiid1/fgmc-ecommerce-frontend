<?php
/* Copyright (C) 2026 FGMC */

require_once DOL_DOCUMENT_ROOT . '/core/triggers/dolibarrtriggers.class.php';
require_once DOL_DOCUMENT_ROOT . '/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT . '/variants/class/ProductCombination.class.php';

/** Pushes selected Dolibarr events to the FGMC integration callback. */
class InterfaceFgmcsyncTriggers extends DolibarrTriggers
{
	public function __construct($db)
	{
		$this->db = $db;
		$this->name = 'FGMCSync';
		$this->family = 'interface';
		$this->description = 'Synchronize invoice, product and stock events with FGMC.';
		$this->version = self::VERSION_DOLIBARR;
		$this->picto = 'technic';
	}

	public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
	{
		if (empty($conf->global->FGMCSYNC_CALLBACK_URL) || empty($conf->global->FGMCSYNC_SHARED_SECRET)) return 0;
		// Products created through the ecommerce API are already the result of a
		// store-to-Dolibarr sync. Do not echo them back as new Dolibarr products.
		// Native combination children are created in the same API call context.
		if (($action === 'PRODUCT_CREATE' || $action === 'PRODUCT_MODIFY') && !empty($object->context)) {
			if (!empty($object->context['caller']) && strtoupper((string) $object->context['caller']) === 'FGMCSYNC') return 0;
			if (!empty($object->context['createproductcombination'])) return 0;
		}
		if ($action === 'STOCK_MOVEMENT' && (string) ($object->inventorycode ?? '') === 'FGMC-SYNC') return 0;

		if ($action === 'BILL_VALIDATE' && !empty($object->id)) {
			$thirdpartyName = '';
			if (!empty($object->socid) && method_exists($object, 'fetch_thirdparty')) {
				$object->fetch_thirdparty();
				$thirdpartyName = (string) ($object->thirdparty->name ?? '');
			}
			return $this->sendEvent('invoice.validated', array(
				'id' => (string) $object->id,
				// Dolibarr 23 calls BILL_VALIDATE before replacing ref=PROV... with
				// the final number. newref already contains that final invoice ref.
				'ref' => (string) ($object->newref ?? $object->ref),
				'ref_client' => (string) ($object->ref_client ?? ''),
				'note_private' => (string) ($object->note_private ?? ''),
				'socid' => (string) ($object->socid ?? ''),
				'customerName' => $thirdpartyName,
				'total_ttc' => (float) ($object->total_ttc ?? 0),
				'date' => (int) ($object->date ?? time()),
				'status' => 'validated',
				'currency' => (string) ($conf->currency ?? 'EUR'),
			));
		}

		if (($action === 'PRODUCT_CREATE' || $action === 'PRODUCT_MODIFY') && !empty($object->id)) {
			return $this->sendEvent('product.updated', array_merge($this->productIdentity($object), array(
				'id' => (string) $object->id,
				'product_id' => (string) $object->id,
				'ref' => (string) ($object->ref ?? ''),
				'label' => (string) ($object->label ?? ''),
				'price_ht' => (float) ($object->price ?? 0),
				'tva_tx' => (float) ($object->tva_tx ?? 0),
			)));
		}

		if ($action === 'STOCK_MOVEMENT' && !empty($object->product_id)) {
			$product = new Product($this->db);
			if ($product->fetch((int) $object->product_id) > 0) {
				$product->load_stock();
				$warehouseId = (int) ($object->warehouse_id ?? $object->entrepot_id ?? 0);
				$quantity = $warehouseId > 0 ? (float) ($product->stock_warehouse[$warehouseId]->real ?? 0) : (float) $product->stock_reel;
				return $this->sendEvent('stock.updated', array_merge($this->productIdentity($product), array(
					'id' => (string) $product->id,
					'product_id' => (string) $product->id,
					'ref' => (string) $product->ref,
					'quantity' => $quantity,
					'warehouse_id' => $warehouseId,
					'movementcode' => (string) ($object->inventorycode ?? ''),
				)));
			}
		}

		return 0;
	}

	private function productIdentity($product)
	{
		$combination = new ProductCombination($this->db);
		$parentId = $combination->fetchByFkProductChild((int) $product->id);
		return array(
			'ref_ext' => (string) ($product->ref_ext ?? ''),
			'is_variant' => $parentId > 0,
			'parent_product_id' => $parentId > 0 ? (string) $parentId : '',
			'store_variant_id' => $parentId > 0 ? (string) ($combination->variation_ref_ext ?? '') : '',
		);
	}

	private function sendEvent($event, array $data)
	{
		$url = (string) getDolGlobalString('FGMCSYNC_CALLBACK_URL');
		$secret = (string) getDolGlobalString('FGMCSYNC_SHARED_SECRET');
		$curl = curl_init($url);
		if (!$curl) return 0;
		$body = json_encode(array('token' => $secret, 'event' => $event, 'data' => $data, 'module_version' => '1.0.7'));
		curl_setopt_array($curl, array(
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $body,
			CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'Accept: application/json'),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_CONNECTTIMEOUT => 4,
			CURLOPT_TIMEOUT => 8,
			CURLOPT_SSL_VERIFYPEER => true,
			CURLOPT_SSL_VERIFYHOST => 2,
		));
		$response = curl_exec($curl);
		$status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$error = curl_error($curl);
		curl_close($curl);
		if ($response === false || $status < 200 || $status >= 300) {
			dol_syslog('FGMCSync callback failed for event ' . $event . ' (HTTP ' . $status . '): ' . ($error ?: 'remote server error'), LOG_WARNING);
			return 0;
		}
		return 1;
	}
}
