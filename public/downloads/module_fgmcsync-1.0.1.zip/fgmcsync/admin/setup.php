<?php
/* Copyright (C) 2026 FGMC */

require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/admin.lib.php';

if (empty($user->admin)) accessforbidden();

$action = GETPOST('action', 'aZ09');
if ($action === 'save') {
	if (!checkToken()) accessforbidden('Invalid token');
	$callbackUrl = trim(GETPOST('callback_url', 'restricthtml'));
	$secret = trim(GETPOST('shared_secret', 'alphanohtml'));
	$parsed = $callbackUrl ? parse_url($callbackUrl) : false;
	if (!$parsed || empty($parsed['scheme']) || empty($parsed['host']) || !in_array(strtolower($parsed['scheme']), array('http', 'https'), true)) {
		setEventMessages('Enter a valid HTTP or HTTPS callback URL.', null, 'errors');
	} elseif ($secret === '') {
		setEventMessages('The shared secret is required.', null, 'errors');
	} else {
		 dolibarr_set_const($db, 'FGMCSYNC_CALLBACK_URL', $callbackUrl, 'chaine', 0, '', $conf->entity);
		 dolibarr_set_const($db, 'FGMCSYNC_SHARED_SECRET', $secret, 'chaine', 0, '', $conf->entity);
		 setEventMessages('FGMC Sync settings saved.', null, 'mesgs');
	}
}

$callbackUrl = getDolGlobalString('FGMCSYNC_CALLBACK_URL');
$configured = getDolGlobalString('FGMCSYNC_SHARED_SECRET') !== '';
llxHeader('', 'FGMC Sync setup');
print load_fiche_titre('FGMC Sync', '', 'title_setup');
print '<div class="opacitymedium">Send validated invoices, product changes and stock updates from Dolibarr to the FGMC store.</div><br>';
print '<form method="POST" action="' . dol_escape_htmltag($_SERVER['PHP_SELF']) . '">';
print '<input type="hidden" name="token" value="' . newToken() . '">';
print '<input type="hidden" name="action" value="save">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td colspan="2">Connection to the FGMC store</td></tr>';
print '<tr><td class="titlefield">Callback URL</td><td><input class="minwidth500" type="url" name="callback_url" required value="' . dol_escape_htmltag($callbackUrl) . '"></td></tr>';
print '<tr><td>Shared secret</td><td><input class="minwidth500" type="password" name="shared_secret" required autocomplete="new-password" placeholder="' . ($configured ? 'Saved; enter again to replace' : 'Paste the token from the FGMC admin page') . '"></td></tr>';
print '</table><br><div class="center">';
print '<input class="button button-save" type="submit" value="Save settings">';
print '</div></form>';
print '<br><div class="info">Copy the callback URL and token from Admin → Modules → Dolibarr in the FGMC store. Use the same URL and token in both systems. This module sends events to the FGMC API; it does not store your Dolibarr login or API key.</div>';
llxFooter();
$db->close();
