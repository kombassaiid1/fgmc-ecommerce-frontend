<?php
require_once DOL_DOCUMENT_ROOT.'/core/triggers/dolibarrtriggers.class.php';

class InterfaceFgmcSyncTriggers extends DolibarrTriggers
{
	public function __construct($db)
	{
		parent::__construct($db);
		$this->family = 'technic';
		$this->description = 'Pushes Dolibarr product, stock, and invoice changes to the FGMC store immediately.';
		$this->version = '1.2.0';
		$this->picto = 'fa-exchange';
	}

	public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
	{
		if (!isModEnabled('fgmcsync')) return 0;
		$syncable = array(
			'PRODUCT_CREATE', 'PRODUCT_MODIFY', 'PRODUCT_PRICE_MODIFY',
			'STOCK_MOVEMENT', 'BILL_CREATE', 'BILL_MODIFY', 'BILL_VALIDATE',
			'BILL_PAYED', 'BILL_CANCEL',
		);
		if (!in_array($action, $syncable, true)) return 0;

		require_once DOL_DOCUMENT_ROOT.'/custom/fgmcsync/class/fgmcsync.class.php';
		$sync = new FgmcSync($this->db);
		return $sync->runEvent($action, $object, $user, $langs, $conf);
	}
}
