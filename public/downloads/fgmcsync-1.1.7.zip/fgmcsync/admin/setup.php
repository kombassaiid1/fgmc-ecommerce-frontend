<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions.lib.php';
require_once DOL_DOCUMENT_ROOT.'/product/stock/class/entrepot.class.php';

if (!$user->admin) accessforbidden();
$action = GETPOST('action', 'aZ09');
$shopUrl = trim(GETPOST('shop_url', 'alphanohtml'));
$shopToken = GETPOST('shop_token', 'alphanohtml');
$warehouseId = GETPOST('warehouse_id', 'int');
$warehouseObject = new Entrepot($db);
$warehouses = $warehouseObject->list_array(1);
if (!is_array($warehouses)) $warehouses = array();

if ($action === 'save') {
	// main.inc.php validates the CSRF token for POST requests.
	$parsedShopUrl = filter_var($shopUrl, FILTER_VALIDATE_URL) ? parse_url($shopUrl) : false;
	$host = is_array($parsedShopUrl) && !empty($parsedShopUrl['host']) ? strtolower(rtrim($parsedShopUrl['host'], '.')) : '';
	$normalizedHost = trim($host, '[]');
	$isLocalHost = ($normalizedHost === 'localhost' || preg_match('/\.localhost$/', $normalizedHost) === 1);
	$isPrivateIp = filter_var($normalizedHost, FILTER_VALIDATE_IP) !== false
		&& filter_var($normalizedHost, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
	if (!is_array($parsedShopUrl) || strtolower($parsedShopUrl['scheme'] ?? '') !== 'https' || $host === '' || $isLocalHost || $isPrivateIp || !empty($parsedShopUrl['user']) || !empty($parsedShopUrl['pass'])) {
		setEventMessages('Enter a valid, publicly reachable HTTPS store API URL. Localhost and private IP addresses cannot be used.', null, 'errors');
	} elseif ($warehouseId > 0 && !array_key_exists($warehouseId, $warehouses)) {
		setEventMessages('The selected warehouse ID is not an active warehouse in this Dolibarr entity. Choose a warehouse from the list below.', null, 'errors');
	} else {
		dolibarr_set_const($db, 'FGMCSYNC_SHOP_URL', rtrim($shopUrl, '/'), 'chaine', 0, '', $conf->entity);
		if ($shopToken !== '') dolibarr_set_const($db, 'FGMCSYNC_SHOP_TOKEN', $shopToken, 'chaine', 0, '', $conf->entity);
		dolibarr_set_const($db, 'FGMCSYNC_WAREHOUSE_ID', max(0, (int) $warehouseId), 'integer', 0, '', $conf->entity);
		dolibarr_set_const($db, 'FGMCSYNC_ENABLED', 1, 'yesno', 0, '', $conf->entity);
		setEventMessages('FGMC Sync settings saved.', null, 'mesgs');
	}
	// Redirect after every POST. Besides avoiding duplicate submissions, this keeps
	// the submitted integration token out of Dolibarr's generated links and history.
	header('Location: '.$_SERVER['PHP_SELF']);
	exit;
}

$langs->loadLangs(array('admin', 'fgmcsync@fgmcsync'));
$pageName = 'FGMC e-commerce synchronization';
llxHeader('', $pageName);
print load_fiche_titre($pageName, '', 'title_setup');
print '<div class="opacitymedium">The Dolibarr URL, REST API key, integration token, and sync directions are managed from the store admin Modules page.</div><br>';
print '<div class="opacitymedium">Choose an active Dolibarr warehouse to synchronize stock for product combinations. The selected warehouse must exist in this Dolibarr entity; quantities there are adjusted to match the store.</div><br>';
print '<form method="POST" action="'.dol_escape_htmltag($_SERVER['PHP_SELF']).'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="save">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td colspan="2">Store connection</td></tr>';
print '<tr><td>Store API base URL</td><td><input required type="url" class="minwidth400" name="shop_url" value="'.dol_escape_htmltag($action === 'save' ? $shopUrl : ($conf->global->FGMCSYNC_SHOP_URL ?? '')).'" placeholder="https://api.example.com"></td></tr>';
print '<tr><td>Store integration token</td><td><input type="password" autocomplete="new-password" required class="minwidth400" name="shop_token" placeholder="Paste the same token saved in the store admin"></td></tr>';
$selectedWarehouseId = (int) ($action === 'save' ? $warehouseId : ($conf->global->FGMCSYNC_WAREHOUSE_ID ?? 0));
print '<tr><td>Warehouse for combination stock</td><td><select class="minwidth300" name="warehouse_id"><option value="0">Select an active warehouse</option>';
foreach ($warehouses as $id => $label) {
	$id = (int) $id;
	print '<option value="'.$id.'"'.($selectedWarehouseId === $id ? ' selected' : '').'>ID '.$id.' - '.dol_escape_htmltag($label).'</option>';
}
print '</select> <span class="opacitymedium">Only existing active warehouses are listed. If this list is empty, enable the Stock module and create/activate a warehouse first.</span></td></tr>';
print '</table><br><div class="center"><input type="submit" class="button button-save" value="Save settings"></div></form>';
print '<br><div class="warning">Copy the integration token from the store admin and paste it here. Use HTTPS for the store API connection.</div>';
llxFooter();
$db->close();
