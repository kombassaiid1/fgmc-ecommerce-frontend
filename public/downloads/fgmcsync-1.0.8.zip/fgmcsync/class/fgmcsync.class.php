<?php
require_once DOL_DOCUMENT_ROOT.'/core/class/commonobject.class.php';

class FgmcSync
{
	private $db;
	private $dolibarrLogin;
	private $dolibarrPassword;
	public function __construct($db) { $this->db = $db; }

	private function request($base, $path, $key, $method = 'GET', $body = null, $integrationToken = null)
	{
		$url = rtrim($base, '/').'/'.ltrim($path, '/');
		$headers = array('Accept: application/json');
		if ($key) {
			$headers[] = 'DOLAPIKEY: '.$key;
			if ($this->dolibarrLogin !== null && $this->dolibarrPassword !== null) {
				$headers[] = 'Authorization: Basic '.base64_encode($this->dolibarrLogin.':'.$this->dolibarrPassword);
			}
		}
		if ($integrationToken) $headers[] = 'X-FGMC-Integration-Token: '.$integrationToken;
		if ($body !== null) $headers[] = 'Content-Type: application/json';
		$ch = curl_init($url);
		curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_CUSTOMREQUEST => $method, CURLOPT_HTTPHEADER => $headers, CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_TIMEOUT => 90, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2));
		if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
		$response = curl_exec($ch); $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE); $error = curl_error($ch); curl_close($ch);
		if ($response === false || $status < 200 || $status >= 300) throw new Exception('HTTP '.$status.' '.$url.': '.($error ?: substr((string) $response, 0, 500)));
		$data = json_decode((string) $response, true);
		return $data === null && $response !== 'null' ? $response : $data;
	}

	private function findByExternalRef($api, $key, $resource, $reference)
	{
		for ($page = 0; $page < 100; $page++) {
			try {
				$rows = $this->request($api, $resource.'?limit=100&page='.$page, $key);
			} catch (Exception $e) {
				// Dolibarr returns HTTP 404 (rather than an empty array) when a
				// collection has no records. Treat that as no match so the sync can
				// create the first third party/order instead of aborting.
				if (stripos($e->getMessage(), 'HTTP 404') !== false && preg_match('/No [a-z ]+ found/i', $e->getMessage())) {
					return null;
				}
				throw $e;
			}
			if (!is_array($rows) || !$rows) return null;
			foreach ($rows as $row) if (($row['ref_ext'] ?? '') === $reference) return $row['id'] ?? $row['rowid'] ?? null;
			if (count($rows) < 100) return null;
		}
		return null;
	}

	private function pushProducts($api, $key, $shop, $token, $syncProducts, $syncStock)
	{
		$page = 0; $count = 0;
		do {
			$items = $this->request($api, 'products?limit=100&page='.$page, $key);
			if (!is_array($items) || !$items) break;
			$products = array(); $stocks = array();
			foreach ($items as $p) {
				if (empty($p['id'])) continue;
				$products[] = array('id' => $p['id'], 'ref' => $p['ref'] ?? ('DOL-'.$p['id']), 'label' => $p['label'] ?? ($p['ref'] ?? 'Dolibarr product'), 'description' => $p['description'] ?? '', 'price' => $p['price'] ?? 0, 'price_ttc' => $p['price_ttc'] ?? null, 'tva_tx' => $p['tva_tx'] ?? 0, 'stock' => $p['stock_reel'] ?? $p['stock'] ?? 0, 'status' => $p['status'] ?? 1, 'image' => '');
				$stocks[] = array('id' => $p['id'], 'qty' => $p['stock_reel'] ?? $p['stock'] ?? 0);
			}
			if ($products) {
				if ($syncProducts) $this->request($shop, 'integrations/dolibarr/products', null, 'POST', array('items' => $products), $token);
				if ($syncStock) $this->request($shop, 'integrations/dolibarr/stock', null, 'POST', array('items' => $stocks), $token);
				$count += count($products);
			}
			$page++;
		} while (count($items) === 100 && $page < 1000);
		return $count;
	}

	private function pushInvoices($api, $key, $shop, $token)
	{
		$items = $this->request($api, 'invoices?limit=100', $key); if (!is_array($items) || !$items) return 0;
		$invoices = array();
		foreach ($items as $invoice) if (!empty($invoice['id'])) $invoices[] = $invoice;
		if ($invoices) $this->request($shop, 'integrations/dolibarr/invoices', null, 'POST', array('items' => $invoices), $token);
		return count($invoices);
	}

	private function pullCustomers($api, $key, $shop, $token)
	{
		$data = $this->request($shop, 'integrations/dolibarr/customers', null, 'GET', null, $token);
		$items = $data['items'] ?? array(); $count = 0;
		foreach ($items as $customer) {
			$address = $customer['addresses'][0] ?? array();
			$name = trim(($customer['firstName'] ?? '').' '.($customer['lastName'] ?? '')) ?: ($customer['company'] ?? 'Store customer');
			$reference = 'FGMC-CUSTOMER-'.$customer['id'];
			$id = $this->findByExternalRef($api, $key, 'thirdparties', $reference);
			if (!$id) {
				$created = $this->request($api, 'thirdparties', $key, 'POST', array(
					'name' => $name, 'client' => 1, 'email' => $customer['email'] ?? '', 'phone' => $customer['phoneNumber'] ?? '',
					'address' => $address['street'] ?? '', 'zip' => $address['zipCode'] ?? '', 'town' => $address['City'] ?? '',
					'country_code' => $address['country'] ?? '', 'ref_ext' => $reference,
				));
				$id = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if ($id) { $this->request($shop, 'integrations/dolibarr/customers/'.$customer['id'].'/link', null, 'POST', array('dolibarrId' => (string) $id), $token); $count++; }
		}
		return $count;
	}

	private function pullOrders($api, $key, $shop, $token)
	{
		$data = $this->request($shop, 'integrations/dolibarr/orders', null, 'GET', null, $token);
		$items = $data['items'] ?? array(); $count = 0;
		foreach ($items as $order) {
			$client = $order['Client'] ?? array(); $address = $order['Address'] ?? array();
			$socid = $client['dolibarrId'] ?? null;
			if (!$socid) {
				$name = $order['guestName'] ?? trim(($client['firstName'] ?? '').' '.($client['lastName'] ?? ''));
				$customerReference = 'FGMC-ORDER-CUSTOMER-'.$order['id'];
				$socid = $this->findByExternalRef($api, $key, 'thirdparties', $customerReference);
				if (!$socid) {
					$created = $this->request($api, 'thirdparties', $key, 'POST', array('name' => ($name ?: 'Store customer'), 'client' => 1, 'email' => $order['guestEmail'] ?? ($client['email'] ?? ''), 'phone' => $order['guestPhone'] ?? ($client['phoneNumber'] ?? ''), 'ref_ext' => $customerReference));
					$socid = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
				}
			}
			if (!$socid) continue;
			$lines = array();
			foreach (($order['products'] ?? array()) as $product) {
				if (empty($product['dolibarrProductId'])) continue;
				$lines[] = array('fk_product' => (int) $product['dolibarrProductId'], 'qty' => (float) ($product['quantity'] ?? 1), 'subprice' => (float) ($product['unitPrice'] ?? 0), 'tva_tx' => 0, 'desc' => $product['title'] ?? '');
			}
			if (!$lines) continue;
			$orderReference = 'FGMC-ORDER-'.$order['id'];
			$id = $this->findByExternalRef($api, $key, 'orders', $orderReference);
			if (!$id) {
				$created = $this->request($api, 'orders', $key, 'POST', array('socid' => (int) $socid, 'date' => strtotime($order['createdAt'] ?? 'now'), 'ref_ext' => $orderReference, 'note_private' => 'Ecommerce order '.$order['id'].' / payment '.$order['paymentStatus']));
				$id = is_array($created) ? ($created['id'] ?? $created['rowid'] ?? null) : $created;
			}
			if ($id) {
				$existing = $this->request($api, 'orders/'.$id.'/lines', $key);
				if (!is_array($existing) || count($existing) === 0) foreach ($lines as $line) $this->request($api, 'orders/'.$id.'/lines', $key, 'POST', array('fk_product' => $line['fk_product'], 'qty' => $line['qty'], 'subprice' => $line['subprice'], 'tva_tx' => $line['tva_tx'], 'desc' => $line['desc']));
				$this->request($shop, 'integrations/dolibarr/orders/'.$order['id'].'/link', null, 'POST', array('dolibarrId' => (string) $id), $token); $count++;
			}
		}
		return $count;
	}

	public function run($user, $langs, $conf)
	{
		return json_encode($this->runDirection('both', $user, $langs, $conf));
	}

	public function runDirection($direction, $user, $langs, $conf)
	{
		$shop = $conf->global->FGMCSYNC_SHOP_URL ?? '';
		$token = $conf->global->FGMCSYNC_SHOP_TOKEN ?? '';
		if (!$shop || !$token) throw new Exception('FGMC Sync bootstrap connection is not configured.');
		$remote = $this->request($shop, 'integrations/dolibarr/runtime-config', null, 'GET', null, $token);
		$api = $remote['apiUrl'] ?? '';
		$key = $remote['apiKey'] ?? '';
		$this->dolibarrLogin = $remote['username'] ?? null;
		$this->dolibarrPassword = $remote['password'] ?? null;
		if (!$api || !$key || !$this->dolibarrLogin || !$this->dolibarrPassword) throw new Exception('Dolibarr URL, Web Services key, login, or password is missing in the store admin.');
		$result = array();
		if ($direction === 'both' || $direction === 'dolibarr-to-store') {
			if (!empty($remote['syncProducts']) || !empty($remote['syncStock'])) $result['products_and_stock'] = $this->pushProducts($api, $key, $shop, $token, !empty($remote['syncProducts']), !empty($remote['syncStock']));
			if (!empty($remote['syncInvoices'])) $result['invoices'] = $this->pushInvoices($api, $key, $shop, $token);
		}
		if ($direction === 'both' || $direction === 'store-to-dolibarr') {
			if (!empty($remote['syncCustomers'])) $result['customers'] = $this->pullCustomers($api, $key, $shop, $token);
			if (!empty($remote['syncOrders'])) $result['orders'] = $this->pullOrders($api, $key, $shop, $token);
		}
		return $result;
	}
}
