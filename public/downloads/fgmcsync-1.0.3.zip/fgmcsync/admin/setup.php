<?php
require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions.lib.php';

if (!$user->admin) accessforbidden();
$action = GETPOST('action', 'aZ09');
$shopUrl = GETPOST('shop_url', 'custom');
$shopToken = GETPOST('shop_token', 'alphanohtml');

if ($action === 'save') {
	// main.inc.php validates the CSRF token for POST requests.
	$parsedShopUrl = parse_url($shopUrl);
	if (empty($parsedShopUrl['scheme']) || $parsedShopUrl['scheme'] !== 'https' || empty($parsedShopUrl['host']) || in_array(strtolower($parsedShopUrl['host']), array('localhost', '127.0.0.1', '::1'), true)) {
		setEventMessages('Enter a publicly reachable HTTPS store API URL. localhost resolves to the Dolibarr server and cannot be used here.', null, 'errors');
	} else {
		dolibarr_set_const($db, 'FGMCSYNC_SHOP_URL', rtrim($shopUrl, '/'), 'chaine', 0, '', $conf->entity);
		if ($shopToken !== '') dolibarr_set_const($db, 'FGMCSYNC_SHOP_TOKEN', $shopToken, 'chaine', 0, '', $conf->entity);
		dolibarr_set_const($db, 'FGMCSYNC_ENABLED', 1, 'yesno', 0, '', $conf->entity);
		header('Location: '.$_SERVER['PHP_SELF']); exit;
	}
}

$langs->loadLangs(array('admin', 'fgmcsync@fgmcsync'));
$pageName = 'FGMC e-commerce synchronization';
llxHeader('', $pageName);
print load_fiche_titre($pageName, '', 'title_setup');
print '<div class="opacitymedium">The Dolibarr URL, REST API key, integration token, and sync directions are managed from the store admin Modules page.</div><br>';
print '<form method="POST" action="'.dol_escape_htmltag($_SERVER['PHP_SELF']).'">';
print '<input type="hidden" name="token" value="'.newToken().'">';
print '<input type="hidden" name="action" value="save">';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td colspan="2">Store connection</td></tr>';
print '<tr><td>Store API base URL</td><td><input required type="url" class="minwidth400" name="shop_url" value="'.dol_escape_htmltag($action === 'save' ? $shopUrl : ($conf->global->FGMCSYNC_SHOP_URL ?? '')).'" placeholder="https://api.example.com"></td></tr>';
print '<tr><td>Store integration token</td><td><input type="password" autocomplete="new-password" required class="minwidth400" name="shop_token" placeholder="Paste the same token saved in the store admin"></td></tr>';
print '</table><br><div class="center"><input type="submit" class="button button-save" value="Save settings"></div></form>';
print '<br><div class="warning">Copy the integration token from the store admin and paste it here. Use HTTPS for the store API connection.</div>';
llxFooter();
$db->close();
