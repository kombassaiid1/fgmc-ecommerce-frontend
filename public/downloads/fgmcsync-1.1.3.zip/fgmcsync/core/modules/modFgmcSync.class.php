<?php
/* Copyright (C) 2026 FGMC */
require_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';

class modFgmcSync extends DolibarrModules
{
	public function __construct($db)
	{
		global $conf;
		$this->db = $db;
		$this->numero = 650100;
		$this->rights_class = 'fgmcsync';
		$this->family = 'technic';
		$this->name = 'FgmcSync';
		$this->description = 'Synchronisation FGMC e-commerce / Dolibarr';
		$this->version = '1.1.3';
		$this->const_name = 'MAIN_MODULE_FGMCSYNC';
		$this->picto = 'fa-exchange';
		$this->module_parts = array();
		$this->dirs = array('/fgmcsync/temp');
		$this->config_page_url = array('setup.php@fgmcsync');
		$this->depends = array('modApi');
		$this->requiredby = array();
		$this->conflictwith = array();
		$this->langfiles = array('fgmcsync@fgmcsync');
		$this->phpmin = array(7, 4);
		$this->need_dolibarr_version = array(20, 0);
		$this->warnings_activation = array();
		$this->warnings_activation_ext = array();
		$this->const = array();
		$this->rights = array();
		$this->menu = array();
		$this->cronjobs = array(
			array('label' => 'FGMC Dolibarr synchronization', 'jobtype' => 'method', 'class' => '/fgmcsync/class/fgmcsync.class.php', 'objectname' => 'FgmcSync', 'method' => 'run', 'parameters' => '', 'comment' => 'Synchronizes configured products, stock, invoices, customers, and orders', 'frequency' => 15, 'unitfrequency' => 60, 'status' => 0, 'test' => '$conf->fgmcsync->enabled', 'priority' => 50),
		);
	}
}
